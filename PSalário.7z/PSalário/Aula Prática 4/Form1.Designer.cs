﻿namespace Aula_Prática_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CbxFilho = new System.Windows.Forms.ComboBox();
            this.CkbxEstadoCivil = new System.Windows.Forms.CheckBox();
            this.RbtnF = new System.Windows.Forms.RadioButton();
            this.RbtnM = new System.Windows.Forms.RadioButton();
            this.TxtNomeFunc = new System.Windows.Forms.TextBox();
            this.BtnVerifDesc = new System.Windows.Forms.Button();
            this.Gbx = new System.Windows.Forms.GroupBox();
            this.MskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.Pnl = new System.Windows.Forms.Panel();
            this.lblDados = new System.Windows.Forms.Label();
            this.mskbxAliqInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalFam = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalLiq = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescInss = new System.Windows.Forms.MaskedTextBox();
            this.Gbx.SuspendLayout();
            this.Pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Funcionário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Salário Bruto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Número de Filhos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Aliquota INSS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 412);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Aliquota IRPF";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 456);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Salário Familia";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 509);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Salário Liquido";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(400, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Desconto INSS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(404, 380);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Desconto IRPF";
            // 
            // CbxFilho
            // 
            this.CbxFilho.FormattingEnabled = true;
            this.CbxFilho.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.CbxFilho.Location = new System.Drawing.Point(138, 121);
            this.CbxFilho.Name = "CbxFilho";
            this.CbxFilho.Size = new System.Drawing.Size(121, 21);
            this.CbxFilho.TabIndex = 9;
            // 
            // CkbxEstadoCivil
            // 
            this.CkbxEstadoCivil.AutoSize = true;
            this.CkbxEstadoCivil.Location = new System.Drawing.Point(29, 37);
            this.CkbxEstadoCivil.Name = "CkbxEstadoCivil";
            this.CkbxEstadoCivil.Size = new System.Drawing.Size(77, 17);
            this.CkbxEstadoCivil.TabIndex = 10;
            this.CkbxEstadoCivil.Text = "Casado (a)";
            this.CkbxEstadoCivil.UseVisualStyleBackColor = true;
            // 
            // RbtnF
            // 
            this.RbtnF.AutoSize = true;
            this.RbtnF.Location = new System.Drawing.Point(29, 39);
            this.RbtnF.Name = "RbtnF";
            this.RbtnF.Size = new System.Drawing.Size(31, 17);
            this.RbtnF.TabIndex = 11;
            this.RbtnF.TabStop = true;
            this.RbtnF.Text = "F";
            this.RbtnF.UseVisualStyleBackColor = true;
            // 
            // RbtnM
            // 
            this.RbtnM.AutoSize = true;
            this.RbtnM.Location = new System.Drawing.Point(29, 75);
            this.RbtnM.Name = "RbtnM";
            this.RbtnM.Size = new System.Drawing.Size(34, 17);
            this.RbtnM.TabIndex = 12;
            this.RbtnM.TabStop = true;
            this.RbtnM.Text = "M";
            this.RbtnM.UseVisualStyleBackColor = true;
            this.RbtnM.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // TxtNomeFunc
            // 
            this.TxtNomeFunc.Location = new System.Drawing.Point(138, 51);
            this.TxtNomeFunc.Name = "TxtNomeFunc";
            this.TxtNomeFunc.Size = new System.Drawing.Size(358, 20);
            this.TxtNomeFunc.TabIndex = 13;
            this.TxtNomeFunc.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            this.TxtNomeFunc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNomeFunc_KeyPress);
            // 
            // BtnVerifDesc
            // 
            this.BtnVerifDesc.Location = new System.Drawing.Point(88, 204);
            this.BtnVerifDesc.Name = "BtnVerifDesc";
            this.BtnVerifDesc.Size = new System.Drawing.Size(223, 39);
            this.BtnVerifDesc.TabIndex = 18;
            this.BtnVerifDesc.Text = "Verifica Desconto";
            this.BtnVerifDesc.UseVisualStyleBackColor = true;
            this.BtnVerifDesc.Click += new System.EventHandler(this.BtnVerifDesc_Click);
            // 
            // Gbx
            // 
            this.Gbx.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Gbx.Controls.Add(this.RbtnF);
            this.Gbx.Controls.Add(this.RbtnM);
            this.Gbx.Location = new System.Drawing.Point(547, 42);
            this.Gbx.Name = "Gbx";
            this.Gbx.Size = new System.Drawing.Size(146, 126);
            this.Gbx.TabIndex = 19;
            this.Gbx.TabStop = false;
            this.Gbx.Text = "Sexo";
            // 
            // MskbxSalBruto
            // 
            this.MskbxSalBruto.Location = new System.Drawing.Point(138, 83);
            this.MskbxSalBruto.Mask = "9999.00";
            this.MskbxSalBruto.Name = "MskbxSalBruto";
            this.MskbxSalBruto.Size = new System.Drawing.Size(186, 20);
            this.MskbxSalBruto.TabIndex = 20;
            // 
            // Pnl
            // 
            this.Pnl.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Pnl.Controls.Add(this.CkbxEstadoCivil);
            this.Pnl.Location = new System.Drawing.Point(547, 189);
            this.Pnl.Name = "Pnl";
            this.Pnl.Size = new System.Drawing.Size(146, 85);
            this.Pnl.TabIndex = 21;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDados.Location = new System.Drawing.Point(24, 285);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(52, 13);
            this.lblDados.TabIndex = 22;
            this.lblDados.Text = "LblDados";
            // 
            // mskbxAliqInss
            // 
            this.mskbxAliqInss.Enabled = false;
            this.mskbxAliqInss.Location = new System.Drawing.Point(138, 362);
            this.mskbxAliqInss.Name = "mskbxAliqInss";
            this.mskbxAliqInss.Size = new System.Drawing.Size(100, 20);
            this.mskbxAliqInss.TabIndex = 23;
            // 
            // mskbxAliqIrpf
            // 
            this.mskbxAliqIrpf.Enabled = false;
            this.mskbxAliqIrpf.Location = new System.Drawing.Point(138, 412);
            this.mskbxAliqIrpf.Name = "mskbxAliqIrpf";
            this.mskbxAliqIrpf.Size = new System.Drawing.Size(100, 20);
            this.mskbxAliqIrpf.TabIndex = 23;
            // 
            // mskbxSalFam
            // 
            this.mskbxSalFam.Enabled = false;
            this.mskbxSalFam.Location = new System.Drawing.Point(138, 456);
            this.mskbxSalFam.Name = "mskbxSalFam";
            this.mskbxSalFam.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalFam.TabIndex = 23;
            // 
            // mskbxSalLiq
            // 
            this.mskbxSalLiq.Enabled = false;
            this.mskbxSalLiq.Location = new System.Drawing.Point(138, 506);
            this.mskbxSalLiq.Name = "mskbxSalLiq";
            this.mskbxSalLiq.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalLiq.TabIndex = 23;
            // 
            // mskbxDescIrpf
            // 
            this.mskbxDescIrpf.Enabled = false;
            this.mskbxDescIrpf.Location = new System.Drawing.Point(507, 380);
            this.mskbxDescIrpf.Name = "mskbxDescIrpf";
            this.mskbxDescIrpf.Size = new System.Drawing.Size(100, 20);
            this.mskbxDescIrpf.TabIndex = 23;
            // 
            // mskbxDescInss
            // 
            this.mskbxDescInss.Enabled = false;
            this.mskbxDescInss.Location = new System.Drawing.Point(507, 337);
            this.mskbxDescInss.Name = "mskbxDescInss";
            this.mskbxDescInss.Size = new System.Drawing.Size(100, 20);
            this.mskbxDescInss.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 550);
            this.Controls.Add(this.mskbxDescInss);
            this.Controls.Add(this.mskbxDescIrpf);
            this.Controls.Add(this.mskbxSalLiq);
            this.Controls.Add(this.mskbxSalFam);
            this.Controls.Add(this.mskbxAliqIrpf);
            this.Controls.Add(this.mskbxAliqInss);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.Pnl);
            this.Controls.Add(this.MskbxSalBruto);
            this.Controls.Add(this.Gbx);
            this.Controls.Add(this.BtnVerifDesc);
            this.Controls.Add(this.TxtNomeFunc);
            this.Controls.Add(this.CbxFilho);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Gbx.ResumeLayout(false);
            this.Gbx.PerformLayout();
            this.Pnl.ResumeLayout(false);
            this.Pnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox CbxFilho;
        private System.Windows.Forms.CheckBox CkbxEstadoCivil;
        private System.Windows.Forms.RadioButton RbtnF;
        private System.Windows.Forms.RadioButton RbtnM;
        private System.Windows.Forms.TextBox TxtNomeFunc;
        private System.Windows.Forms.Button BtnVerifDesc;
        private System.Windows.Forms.GroupBox Gbx;
        private System.Windows.Forms.MaskedTextBox MskbxSalBruto;
        private System.Windows.Forms.Panel Pnl;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.MaskedTextBox mskbxAliqInss;
        private System.Windows.Forms.MaskedTextBox mskbxAliqIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxSalFam;
        private System.Windows.Forms.MaskedTextBox mskbxSalLiq;
        private System.Windows.Forms.MaskedTextBox mskbxDescIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxDescInss;
    }
}

